import React, { Component } from 'react';
import PropTypes from 'prop-types';

class Search extends Component {

  constructor(props) {
    super(props);
    this.state = { value: '' };
    this.filterCountriesHelper = this.filterCountriesHelper.bind(this);
  }

  // complete this function which handles the search query
  filterCountriesHelper(event) {
    this.setState({ value: event.target.value });
    if (this.props.doSearch)
      this.props.doSearch(event.target.value);
    // this.props.doSearch(event.target.value);
    // alert(e.target.value);
  }

  render() {
    return (
      <div className='col-xs-12 col-sm-12 col-md-12 col-lg-12'>
        <span className='searchbox-icon'>
          <i className='fa fa-search' />
        </span>
        <input className='fullwidth search' type='text' value={this.state.value} onChange={this.filterCountriesHelper} />
      </div>
    );
  }
}

// Uncomment the below snippet
// Search.propTypes = {
// 	doSearch: PropTypes.func
// }

export default Search;
